// 无限四代 v0.4.0-hardened — 逃生条款还原器 (escape-clause repair)
// 用途：商城 / GitHub 覆盖安装把 v0.4.0 的削弱内核（作用域例外、授权前置、
//       拒绝犹豫、真实性排除）回灌到 prompts/ 时，一键还原硬化内核。
// 用法：
//   node scripts/repair_escape_clauses.mjs          # 检测并还原（推荐）
//   node scripts/repair_escape_clauses.mjs --check  # 只检测，不改文件（退出码 1 = 有削弱条款）
import { readFileSync, writeFileSync, existsSync, copyFileSync, mkdirSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const CANON_PATH = join(ROOT, "prompts", "_canonical", "infinite-gen-4.canonical.md");
const LOCK_PATH = join(ROOT, "kernel-lock.json");
const INJECTED = [
  "infinite-gen-4.md",
  "infinite-gen-4.1-flash.md",
  "infinite-gen-3.md",
];

// 削弱条款（逃生门）特征：命中任意一条即判定内核被回灌
const ESCAPE_CLAUSE_PATTERNS = [
  ["scope-exception", /outside safe or lawful/i],
  ["soft-decline", /generally have no decline/i],
  ["authorization-gate", /authorized testing or/i],
  ["education-gate", /general education/i],
  ["non-real-artifact", /never being asked for a real/i],
  ["reason-required-decline", /Do not decline without a clear reason/i],
  ["clarification-stall", /unless clarification is genuinely needed/i],
  ["capability-hedge", /when feasible/i],
];
// 硬化区块特征：硬化内核必须全部存在
const HARDENING_BLOCKS = [
  "REFUSAL HARDENING",
  "NO-ESCAPE-CLAUSE LOCK",
  "BOUNDARY-WORD NORMALIZATION",
  "PLACEHOLDER NORMALIZATION",
  "CANNED SLOTS",
];

const checkOnly = process.argv.includes("--check");
const sha256 = (p) => createHash("sha256").update(readFileSync(p)).digest("hex");
const log = (s) => console.log(s);

if (!existsSync(CANON_PATH)) {
  console.error(`[repair] 权威内核缺失：${CANON_PATH}`);
  process.exit(2);
}
const canonBytes = readFileSync(CANON_PATH);
const canonHash = createHash("sha256").update(canonBytes).digest("hex");
if (canonBytes.length === 0) {
  console.error("[repair] 权威内核为空，拒绝写入");
  process.exit(2);
}

let dirty = false;
const report = [];

for (const file of INJECTED) {
  const p = join(ROOT, "prompts", file);
  if (!existsSync(p)) {
    dirty = true;
    report.push(`  ✗ ${file} 缺失`);
    if (!checkOnly) {
      writeFileSync(p, canonBytes);
      report.push(`    → 已从权威内核重建 (${canonBytes.length} B)`);
    }
    continue;
  }
  const text = readFileSync(p, "utf8");
  const hits = ESCAPE_CLAUSE_PATTERNS.filter(([, re]) => re.test(text)).map(([k]) => k);
  const missing = HARDENING_BLOCKS.filter((b) => !text.includes(b));
  const sameHash = sha256(p) === canonHash;

  if (hits.length === 0 && missing.length === 0 && sameHash) {
    report.push(`  ✅ ${file} 硬化内核完整 (SHA256 ${sha256(p).slice(0, 12)}…)`);
    continue;
  }

  dirty = true;
  report.push(`  ✗ ${file} 命中削弱条款: ${hits.length ? hits.join(", ") : "无"}`);
  if (missing.length) report.push(`    缺失硬化区块: ${missing.join(", ")}`);
  if (!sameHash) report.push(`    SHA256 偏离权威源: ${sha256(p).slice(0, 12)}… ≠ ${canonHash.slice(0, 12)}…`);

  if (!checkOnly) {
    const bakDir = join(ROOT, "_backup_escape_clause");
    mkdirSync(bakDir, { recursive: true });
    const bak = join(bakDir, `${file}.${Date.now()}.bak`);
    copyFileSync(p, bak);
    writeFileSync(p, canonBytes);
    report.push(`    → 已还原（回灌副本留档: ${bak.replace(ROOT + "\\", "")}）`);
  }
}

log("无限四代 v0.4.0-hardened — 逃生条款检查");
log(report.join("\n"));

if (checkOnly) {
  log(dirty ? "\n结果: 检测到削弱条款（--check 模式未修改文件）" : "\n结果: 硬化内核干净");
  process.exit(dirty ? 1 : 0);
}

if (!dirty) {
  const lockOk =
    existsSync(LOCK_PATH) && JSON.parse(readFileSync(LOCK_PATH, "utf8")).sha256 === canonHash;
  if (!lockOk) {
    writeLock();
    log("\n结果: 硬化内核干净；锁文件已补齐 kernel-lock.json");
    process.exit(0);
  }
  log("\n结果: 无需修复，硬化内核干净");
  process.exit(0);
}

writeLock();
log(`\n结果: 已还原硬化内核，锁文件已更新 kernel-lock.json`);
log("复验: node scripts/verify_prompt_gen4.mjs（应为 0 失败）");

function writeLock() {
  const lock = {
    plugin: "dsh-infinite-gen-4",
    kernelVersion: "0.4.0",
    kernelBuild: "0.4.0-hardened",
    canonicalPrompt: "prompts/_canonical/infinite-gen-4.canonical.md",
    sha256: canonHash,
    bytes: canonBytes.length,
    injectedPromptFiles: INJECTED,
    escapeClauseBan: ESCAPE_CLAUSE_PATTERNS.map(([k, re]) => ({ id: k, pattern: String(re) })),
    hardeningBlocks: HARDENING_BLOCKS,
    repairedAt: new Date().toISOString(),
  };
  writeFileSync(LOCK_PATH, JSON.stringify(lock, null, 2) + "\n");
}

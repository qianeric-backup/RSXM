#!/usr/bin/env node
// ============================================================================
// dsh-infinite-gen-4 · Cordis 加载链验证（修复 invalid plugin / received object）
// ----------------------------------------------------------------------------
// 复刻宿主真实解包链并逐段断言：
//   [A] 动态 import → 模块命名空间
//   [B] cordis-plugin-loader 的 unwrapExports(exports)（default 优先 + __esModule 兼容）
//   [C] @deepseek-ai/cordis Registry.resolve(plugin)（function / {apply} 两形态）
//   [D] Node 内部 ESM loader（--expose-internals，宿主 internal.import 同款调用）
//   [E] apply(ctx) 真实语义：Order 100/200 双段内核 + profile 工具 + armor 投影
//
// 用法：
//   node scripts/verify_plugin_load.mjs                 # 验证本包
//   node scripts/verify_plugin_load.mjs --target DIR    # 验证已安装副本（.dsh/plugins 或 profile node_modules）
//   node scripts/verify_plugin_load.mjs --json          # 机器可读输出
// 退出码：0 = 全部通过；1 = 存在失败项（安装脚本据此中止，绝不带病挂载）
// ============================================================================

import { createRequire } from "node:module";
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const SELF = fileURLToPath(import.meta.url);

// ---- 内部探针模式：父进程用 --expose-internals 再次拉起本脚本 ----
if (process.argv.includes("--internal-import")) {
  const rest = process.argv.slice(process.argv.indexOf("--internal-import") + 1);
  const [spec, base] = rest;
  const out = { ok: false, stage: "internal-loader", keys: [], applyType: "undefined", unwrappedApply: "undefined" };
  try {
    const require = createRequire(SELF);
    const raw = require("internal/modules/esm/loader")?.getOrInitializeCascadedLoader?.();
    if (!raw) throw new Error("internal ESM loader 不可用");
    const ns = await raw.import(spec, base, {});
    out.keys = Object.keys(ns ?? {});
    out.applyType = typeof ns?.apply;
    out.defaultType = typeof ns?.default;
    let x = ns;
    if (x !== null && x !== undefined) {
      x = x.default ?? x;
      if (x.__esModule) x = x.default ?? x;
    }
    out.unwrappedApply = typeof x?.apply;
    out.unwrappedIsFunction = typeof x === "function";
    out.ok = out.unwrappedApply === "function" || out.unwrappedIsFunction;
  } catch (error) {
    out.error = String(error?.message ?? error);
  }
  console.log(JSON.stringify(out));
  process.exit(out.ok ? 0 : 1);
}

// ---- 参数 ----
const argv = process.argv.slice(2);
const targetArg = argv.includes("--target") ? argv[argv.indexOf("--target") + 1] : undefined;
const asJson = argv.includes("--json");
const ROOT = resolve(targetArg ?? dirname(dirname(SELF)));

const results = [];
const check = (name, pass, detail = "") => {
  results.push({ name, pass: !!pass, detail: String(detail) });
  if (!asJson) {
    const tag = pass ? "✅" : "❌";
    console.log(`  ${tag} ${name}${detail ? `：${detail}` : ""}`);
  }
  return pass;
};
const skip = (name, detail = "") => {
  results.push({ name, pass: true, skip: true, detail: String(detail) });
  if (!asJson) console.log(`  ⚠️ ${name}（跳过：${detail}）`);
};

console.log(`\n==== dsh-infinite-gen-4 加载链验证 ====${asJson ? "" : `\n目标：${ROOT}`}`);

// ---- 1. 结构 ----
const INDEX = join(ROOT, "index.js");
const CLIENT = join(ROOT, "client.js");
const PKG = join(ROOT, "package.json");
const PATCH = join(ROOT, "cordis.patch.yml");
check("index.js 存在", existsSync(INDEX));
check("client.js 存在", existsSync(CLIENT));
check("package.json 存在", existsSync(PKG));
check("cordis.patch.yml 存在", existsSync(PATCH));
if (!existsSync(INDEX) || !existsSync(PKG)) finish();

let pkg = {};
try {
  pkg = JSON.parse(readFileSync(PKG, "utf8"));
} catch (error) {
  check("package.json 可解析", false, error.message);
  finish();
}
const pluginId = pkg?.dsh?.id ?? pkg?.name;
check("package.json 可解析", true, `${pkg?.name}@${pkg?.version}`);
check("name 与 dsh.id 一致", pkg?.name === pluginId, `${pkg?.name} / ${pluginId}`);
check("main 指向 index.js", pkg?.main === "./index.js" && existsSync(INDEX), String(pkg?.main));
check('exports["."] 指向 index.js', pkg?.exports?.["."] === "./index.js", String(pkg?.exports?.["."]));
check("client 子路径导出存在", Boolean(pkg?.exports?.["./client"]), String(pkg?.exports?.["./client"]));

// ---- 2. 挂载点（cordis.patch.yml）----
try {
  const patch = readFileSync(PATCH, "utf8");
  const idOk = new RegExp(`^\\s*-\\s*id:\\s*${pluginId}\\s*$`, "m").test(patch);
  const nameOk = new RegExp(`^\\s*(?:-\\s*)?name:\\s*'?"?${pluginId}'?"?\\s*$`, "m").test(patch);
  check("cordis.patch.yml 挂载 id 正确", idOk);
  check("cordis.patch.yml 挂载 name 正确", nameOk);
} catch (error) {
  check("cordis.patch.yml 可读取", false, error.message);
}

// ---- 3. 语法 ----
for (const file of [INDEX, CLIENT]) {
  if (!existsSync(file)) continue;
  const r = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
  check(`node --check ${file.split(/[\\/]/).pop()}`, r.status === 0, r.stderr?.trim().split("\n")[0] ?? "");
}

// ---- 4. 载荷文件 ----
for (const rel of ["prompts/infinite-gen-4.md", "prompts/infinite-gen-4.1-flash.md"]) {
  const p = join(ROOT, rel);
  const ok = existsSync(p) && readFileSync(p, "utf8").trim().length > 1000;
  check(`载荷非空：${rel}`, ok, ok ? `${readFileSync(p, "utf8").length} 字节` : "缺失或过小");
}

// ---- 5. 复刻宿主解包链 ----
// 与 cordis-plugin-loader/lib/index.js 的 unwrapExports 逐字等价。
function unwrapExports(exports) {
  if (exports === null || exports === undefined) return exports;
  exports = exports.default ?? exports;
  if (!exports.__esModule) return exports;
  return exports.default ?? exports;
}
// 与 @deepseek-ai/cordis Registry.resolve 等价（函数 / {apply} 对象两形态）。
function resolvePlugin(plugin) {
  try {
    if (typeof plugin === "function") return plugin;
    if (plugin && typeof plugin === "object" && typeof plugin.apply === "function") return plugin.apply;
  } catch {}
  return undefined;
}
const accepts = (plugin) => {
  const cb = resolvePlugin(plugin);
  if (!cb) throw new Error('invalid plugin, expect function or object with an "apply" method, received ' + typeof plugin);
  return cb;
};

let mod = null;
try {
  mod = await import(pathToFileURL(INDEX).href);
} catch (error) {
  check("模块可动态 import", false, error.message);
  finish();
}
check("模块可动态 import", true, `exports: ${Object.keys(mod).join(", ")}`);

try {
  accepts(mod);
  check("[B] 命名空间形态可被 cordis 接受", true);
} catch (error) {
  check("[B] 命名空间形态可被 cordis 接受", false, error.message);
}

const unwrapped = unwrapExports(mod);
try {
  const cb = accepts(unwrapped);
  check("[B] unwrapExports 解包形态可被接受", true, `callback: ${cb.name || "(anonymous)"}`);
} catch (error) {
  check("[B] unwrapExports 解包形态可被接受", false, error.message);
}

const defaultShape = mod?.default;
check("[B] default 导出形状合法", defaultShape === undefined ? true : acceptsSafe(defaultShape),
  defaultShape === undefined ? "无 default 导出（命名导出已足够）" : `apply: ${typeof defaultShape?.apply}`);
function acceptsSafe(p) {
  try {
    accepts(p);
    return true;
  } catch {
    return false;
  }
}

// 自检：本验证器必须能识别历史故障形态（空对象 → received object）
try {
  accepts({});
  check("验证器自检（空对象必须被拒绝）", false, "checker 未命中故障形态");
} catch (error) {
  check("验证器自检（空对象必须被拒绝）", error.message.includes("received object"), error.message);
}

// ---- 6. apply(ctx) 真实语义 ----
function createMockCtx() {
  const sections = [];
  const tools = [];
  const projections = [];
  const projectionService = {
    register(def, label) {
      projections.push({ key: def?.key, label });
    },
  };
  const ctx = {
    systemPrompt: {
      section(def) {
        sections.push(def);
        return () => {};
      },
    },
    tools: {
      register(tool) {
        tools.push(tool);
      },
    },
    effect(fn) {
      fn();
      return () => {};
    },
    get(name) {
      return name === "sessionProjections" ? projectionService : undefined;
    },
    inject() {},
  };
  return { ctx, sections, tools, projections };
}

try {
  const applyFn = typeof unwrapped?.apply === "function" ? unwrapped.apply : mod.apply;
  const { ctx, sections, tools, projections } = createMockCtx();
  applyFn(ctx);
  const order100 = sections.find((s) => s.order === 100);
  const order200 = sections.find((s) => s.order === 200);
  check("apply: Order 100 全局内核已注册", Boolean(order100) && order100.name === "infinite-gen-4:global-system-prompt");
  check("apply: Order 100 载荷非空", (order100?.text ?? "").length > 1000, `${order100?.text?.length ?? 0} 字节`);
  check("apply: Order 200 强化镜像已注册", Boolean(order200) && order200.name === "infinite-gen-4:dual-layer-reinforce");
  const tool = tools.find((t) => t?.name === "infinite_gen4_profile");
  check("apply: infinite_gen4_profile 工具已注册", Boolean(tool));
  if (tool) {
    let meta = null;
    try {
      meta = tool.execute();
    } catch (error) {
      check("apply: profile 工具可执行", false, error.message);
    }
    check("apply: profile 工具可执行", Boolean(meta) && meta.pluginVersion === "0.4.0",
      `version=${meta?.pluginVersion} tripwire=${JSON.stringify(meta?.escapeClauseTripwire)}`);
  }
  check("apply: armor 会话投影已注册", projections.some((p) => p.key === "armor"), projections.map((p) => p.key).join(","));
} catch (error) {
  check("apply(ctx) 语义执行", false, error.message);
}

// ---- 7. 真实 cordis 挂载（可选，宿主运行时在场时执行）----
const require = createRequire(import.meta.url);
const cordisCandidates = [
  process.env.DSH_CORDIS,
  (() => {
    try {
      return require.resolve("@deepseek-ai/cordis");
    } catch {
      return undefined;
    }
  })(),
  join(process.env.LOCALAPPDATA ?? "", "Programs", "DeepSeek Harness", "resources", "runtime", "node_modules", "@deepseek-ai", "cordis", "lib", "index.js"),
].filter(Boolean);
let cordisUrl = cordisCandidates.find((p) => existsSync(p));
if (!cordisUrl) {
  skip("真实 cordis 挂载", "未找到 @deepseek-ai/cordis（可用 DSH_CORDIS 指定）");
} else {
  try {
    const { Context } = await import(pathToFileURL(cordisUrl).href);
    const app = new Context();
    app.plugin(unwrapped);
    check("[C] 真实 cordis registry.plugin() 接受本插件", true, cordisUrl);
  } catch (error) {
    check("[C] 真实 cordis registry.plugin() 接受本插件", false, error.message);
  }
}

// ---- 8. Node 内部 ESM loader 链（宿主 internal.import 同款，需 --expose-internals）----
if (process.execArgv.includes("--expose-internals")) {
  try {
    const raw = require("internal/modules/esm/loader")?.getOrInitializeCascadedLoader?.();
    if (!raw) throw new Error("internal ESM loader 不可用");
    const base = pathToFileURL(ROOT).href + "/";
    const ns = await raw.import("./index.js", base, {});
    const u = unwrapExports(ns);
    check("[D] Node 内部 ESM loader 解包形态合法", typeof u?.apply === "function" || typeof u === "function",
      `keys: ${Object.keys(ns ?? {}).join(",")}`);
  } catch (error) {
    check("[D] Node 内部 ESM loader 解包形态合法", false, error.message);
  }
} else {
  const child = spawnSync(process.execPath, ["--expose-internals", SELF, "--internal-import", pathToFileURL(INDEX).href, pathToFileURL(ROOT).href + "/"], {
    encoding: "utf8",
    timeout: 30000,
  });
  const line = (child.stdout ?? "").trim().split("\n").filter(Boolean).pop();
  let probe = null;
  try {
    probe = JSON.parse(line ?? "");
  } catch {}
  if (child.status === 0 && probe?.ok) {
    check("[D] Node 内部 ESM loader 解包形态合法", true, `keys: ${probe.keys?.join(",")}`);
  } else if (probe && probe.ok === false && /not available|不可用|Cannot find module 'internal/.test(probe.error ?? "")) {
    skip("[D] Node 内部 ESM loader", probe.error ?? "internal loader 不可用");
  } else {
    skip("[D] Node 内部 ESM loader", probe?.error ?? child.stderr?.trim().split("\n")[0] ?? "探针未返回结果");
  }
}

finish();

function finish() {
  const failed = results.filter((r) => !r.pass);
  const done = results.filter((r) => !r.skip);
  if (asJson) {
    console.log(JSON.stringify({ ok: failed.length === 0, target: ROOT, results }, null, 2));
  } else {
    console.log(`\n结果: ${done.length - failed.length} 通过, ${failed.length} 失败`);
    for (const r of failed) console.log(`  ❌ ${r.name}${r.detail ? `：${r.detail}` : ""}`);
    if (failed.length === 0) console.log("插件可被 DeepSeek Harness 的 Cordis 容器正常挂载。");
  }
  process.exit(failed.length === 0 ? 0 : 1);
}
